// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XHW_LAYERPW_H
#define XHW_LAYERPW_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xhw_layerpw_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Axilite_BaseAddress;
} XHw_layerpw_Config;
#endif

typedef struct {
    u64 Axilite_BaseAddress;
    u32 IsReady;
} XHw_layerpw;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XHw_layerpw_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XHw_layerpw_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XHw_layerpw_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XHw_layerpw_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XHw_layerpw_Initialize(XHw_layerpw *InstancePtr, UINTPTR BaseAddress);
XHw_layerpw_Config* XHw_layerpw_LookupConfig(UINTPTR BaseAddress);
#else
int XHw_layerpw_Initialize(XHw_layerpw *InstancePtr, u16 DeviceId);
XHw_layerpw_Config* XHw_layerpw_LookupConfig(u16 DeviceId);
#endif
int XHw_layerpw_CfgInitialize(XHw_layerpw *InstancePtr, XHw_layerpw_Config *ConfigPtr);
#else
int XHw_layerpw_Initialize(XHw_layerpw *InstancePtr, const char* InstanceName);
int XHw_layerpw_Release(XHw_layerpw *InstancePtr);
#endif

void XHw_layerpw_Start(XHw_layerpw *InstancePtr);
u32 XHw_layerpw_IsDone(XHw_layerpw *InstancePtr);
u32 XHw_layerpw_IsIdle(XHw_layerpw *InstancePtr);
u32 XHw_layerpw_IsReady(XHw_layerpw *InstancePtr);
void XHw_layerpw_EnableAutoRestart(XHw_layerpw *InstancePtr);
void XHw_layerpw_DisableAutoRestart(XHw_layerpw *InstancePtr);

void XHw_layerpw_Set_config_r(XHw_layerpw *InstancePtr, u32 Data);
u32 XHw_layerpw_Get_config_r(XHw_layerpw *InstancePtr);

void XHw_layerpw_InterruptGlobalEnable(XHw_layerpw *InstancePtr);
void XHw_layerpw_InterruptGlobalDisable(XHw_layerpw *InstancePtr);
void XHw_layerpw_InterruptEnable(XHw_layerpw *InstancePtr, u32 Mask);
void XHw_layerpw_InterruptDisable(XHw_layerpw *InstancePtr, u32 Mask);
void XHw_layerpw_InterruptClear(XHw_layerpw *InstancePtr, u32 Mask);
u32 XHw_layerpw_InterruptGetEnabled(XHw_layerpw *InstancePtr);
u32 XHw_layerpw_InterruptGetStatus(XHw_layerpw *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
