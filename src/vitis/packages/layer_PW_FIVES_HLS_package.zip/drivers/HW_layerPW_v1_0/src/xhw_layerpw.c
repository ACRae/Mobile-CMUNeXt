// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xhw_layerpw.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XHw_layerpw_CfgInitialize(XHw_layerpw *InstancePtr, XHw_layerpw_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilite_BaseAddress = ConfigPtr->Axilite_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XHw_layerpw_Start(XHw_layerpw *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_layerpw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_AP_CTRL) & 0x80;
    XHw_layerpw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_AP_CTRL, Data | 0x01);
}

u32 XHw_layerpw_IsDone(XHw_layerpw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_layerpw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XHw_layerpw_IsIdle(XHw_layerpw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_layerpw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XHw_layerpw_IsReady(XHw_layerpw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_layerpw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XHw_layerpw_EnableAutoRestart(XHw_layerpw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerpw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_AP_CTRL, 0x80);
}

void XHw_layerpw_DisableAutoRestart(XHw_layerpw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerpw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_AP_CTRL, 0);
}

void XHw_layerpw_Set_config_r(XHw_layerpw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerpw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_CONFIG_R_DATA, Data);
}

u32 XHw_layerpw_Get_config_r(XHw_layerpw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_layerpw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_CONFIG_R_DATA);
    return Data;
}

void XHw_layerpw_InterruptGlobalEnable(XHw_layerpw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerpw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_GIE, 1);
}

void XHw_layerpw_InterruptGlobalDisable(XHw_layerpw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerpw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_GIE, 0);
}

void XHw_layerpw_InterruptEnable(XHw_layerpw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHw_layerpw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_IER);
    XHw_layerpw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_IER, Register | Mask);
}

void XHw_layerpw_InterruptDisable(XHw_layerpw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHw_layerpw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_IER);
    XHw_layerpw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_IER, Register & (~Mask));
}

void XHw_layerpw_InterruptClear(XHw_layerpw *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerpw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_ISR, Mask);
}

u32 XHw_layerpw_InterruptGetEnabled(XHw_layerpw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHw_layerpw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_IER);
}

u32 XHw_layerpw_InterruptGetStatus(XHw_layerpw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHw_layerpw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERPW_AXILITE_ADDR_ISR);
}

