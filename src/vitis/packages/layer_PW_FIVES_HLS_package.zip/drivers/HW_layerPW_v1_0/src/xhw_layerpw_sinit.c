// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xhw_layerpw.h"

extern XHw_layerpw_Config XHw_layerpw_ConfigTable[];

#ifdef SDT
XHw_layerpw_Config *XHw_layerpw_LookupConfig(UINTPTR BaseAddress) {
	XHw_layerpw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XHw_layerpw_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XHw_layerpw_ConfigTable[Index].Axilite_BaseAddress == BaseAddress) {
			ConfigPtr = &XHw_layerpw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHw_layerpw_Initialize(XHw_layerpw *InstancePtr, UINTPTR BaseAddress) {
	XHw_layerpw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHw_layerpw_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHw_layerpw_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XHw_layerpw_Config *XHw_layerpw_LookupConfig(u16 DeviceId) {
	XHw_layerpw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XHW_LAYERPW_NUM_INSTANCES; Index++) {
		if (XHw_layerpw_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XHw_layerpw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHw_layerpw_Initialize(XHw_layerpw *InstancePtr, u16 DeviceId) {
	XHw_layerpw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHw_layerpw_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHw_layerpw_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

