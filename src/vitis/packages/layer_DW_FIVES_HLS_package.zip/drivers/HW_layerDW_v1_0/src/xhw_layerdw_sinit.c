// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xhw_layerdw.h"

extern XHw_layerdw_Config XHw_layerdw_ConfigTable[];

#ifdef SDT
XHw_layerdw_Config *XHw_layerdw_LookupConfig(UINTPTR BaseAddress) {
	XHw_layerdw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XHw_layerdw_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XHw_layerdw_ConfigTable[Index].Axilite_BaseAddress == BaseAddress) {
			ConfigPtr = &XHw_layerdw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHw_layerdw_Initialize(XHw_layerdw *InstancePtr, UINTPTR BaseAddress) {
	XHw_layerdw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHw_layerdw_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHw_layerdw_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XHw_layerdw_Config *XHw_layerdw_LookupConfig(u16 DeviceId) {
	XHw_layerdw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XHW_LAYERDW_NUM_INSTANCES; Index++) {
		if (XHw_layerdw_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XHw_layerdw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHw_layerdw_Initialize(XHw_layerdw *InstancePtr, u16 DeviceId) {
	XHw_layerdw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHw_layerdw_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHw_layerdw_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

