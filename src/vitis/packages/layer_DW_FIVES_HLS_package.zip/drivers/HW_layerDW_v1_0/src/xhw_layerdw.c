// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xhw_layerdw.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XHw_layerdw_CfgInitialize(XHw_layerdw *InstancePtr, XHw_layerdw_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilite_BaseAddress = ConfigPtr->Axilite_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XHw_layerdw_Start(XHw_layerdw *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_layerdw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_AP_CTRL) & 0x80;
    XHw_layerdw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_AP_CTRL, Data | 0x01);
}

u32 XHw_layerdw_IsDone(XHw_layerdw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_layerdw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XHw_layerdw_IsIdle(XHw_layerdw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_layerdw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XHw_layerdw_IsReady(XHw_layerdw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_layerdw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XHw_layerdw_EnableAutoRestart(XHw_layerdw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerdw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_AP_CTRL, 0x80);
}

void XHw_layerdw_DisableAutoRestart(XHw_layerdw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerdw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_AP_CTRL, 0);
}

void XHw_layerdw_Set_config_r(XHw_layerdw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerdw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_CONFIG_R_DATA, Data);
}

u32 XHw_layerdw_Get_config_r(XHw_layerdw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_layerdw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_CONFIG_R_DATA);
    return Data;
}

void XHw_layerdw_InterruptGlobalEnable(XHw_layerdw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerdw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_GIE, 1);
}

void XHw_layerdw_InterruptGlobalDisable(XHw_layerdw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerdw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_GIE, 0);
}

void XHw_layerdw_InterruptEnable(XHw_layerdw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHw_layerdw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_IER);
    XHw_layerdw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_IER, Register | Mask);
}

void XHw_layerdw_InterruptDisable(XHw_layerdw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHw_layerdw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_IER);
    XHw_layerdw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_IER, Register & (~Mask));
}

void XHw_layerdw_InterruptClear(XHw_layerdw *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_layerdw_WriteReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_ISR, Mask);
}

u32 XHw_layerdw_InterruptGetEnabled(XHw_layerdw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHw_layerdw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_IER);
}

u32 XHw_layerdw_InterruptGetStatus(XHw_layerdw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHw_layerdw_ReadReg(InstancePtr->Axilite_BaseAddress, XHW_LAYERDW_AXILITE_ADDR_ISR);
}

