// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XHW_LAYERDW_H
#define XHW_LAYERDW_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xhw_layerdw_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Axilite_BaseAddress;
} XHw_layerdw_Config;
#endif

typedef struct {
    u64 Axilite_BaseAddress;
    u32 IsReady;
} XHw_layerdw;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XHw_layerdw_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XHw_layerdw_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XHw_layerdw_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XHw_layerdw_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XHw_layerdw_Initialize(XHw_layerdw *InstancePtr, UINTPTR BaseAddress);
XHw_layerdw_Config* XHw_layerdw_LookupConfig(UINTPTR BaseAddress);
#else
int XHw_layerdw_Initialize(XHw_layerdw *InstancePtr, u16 DeviceId);
XHw_layerdw_Config* XHw_layerdw_LookupConfig(u16 DeviceId);
#endif
int XHw_layerdw_CfgInitialize(XHw_layerdw *InstancePtr, XHw_layerdw_Config *ConfigPtr);
#else
int XHw_layerdw_Initialize(XHw_layerdw *InstancePtr, const char* InstanceName);
int XHw_layerdw_Release(XHw_layerdw *InstancePtr);
#endif

void XHw_layerdw_Start(XHw_layerdw *InstancePtr);
u32 XHw_layerdw_IsDone(XHw_layerdw *InstancePtr);
u32 XHw_layerdw_IsIdle(XHw_layerdw *InstancePtr);
u32 XHw_layerdw_IsReady(XHw_layerdw *InstancePtr);
void XHw_layerdw_EnableAutoRestart(XHw_layerdw *InstancePtr);
void XHw_layerdw_DisableAutoRestart(XHw_layerdw *InstancePtr);

void XHw_layerdw_Set_config_r(XHw_layerdw *InstancePtr, u32 Data);
u32 XHw_layerdw_Get_config_r(XHw_layerdw *InstancePtr);

void XHw_layerdw_InterruptGlobalEnable(XHw_layerdw *InstancePtr);
void XHw_layerdw_InterruptGlobalDisable(XHw_layerdw *InstancePtr);
void XHw_layerdw_InterruptEnable(XHw_layerdw *InstancePtr, u32 Mask);
void XHw_layerdw_InterruptDisable(XHw_layerdw *InstancePtr, u32 Mask);
void XHw_layerdw_InterruptClear(XHw_layerdw *InstancePtr, u32 Mask);
u32 XHw_layerdw_InterruptGetEnabled(XHw_layerdw *InstancePtr);
u32 XHw_layerdw_InterruptGetStatus(XHw_layerdw *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
