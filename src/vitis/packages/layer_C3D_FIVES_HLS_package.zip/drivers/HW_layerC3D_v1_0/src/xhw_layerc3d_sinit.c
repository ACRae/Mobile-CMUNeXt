// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xhw_layerc3d.h"

extern XHw_layerc3d_Config XHw_layerc3d_ConfigTable[];

#ifdef SDT
XHw_layerc3d_Config *XHw_layerc3d_LookupConfig(UINTPTR BaseAddress) {
	XHw_layerc3d_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XHw_layerc3d_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XHw_layerc3d_ConfigTable[Index].Axilite_BaseAddress == BaseAddress) {
			ConfigPtr = &XHw_layerc3d_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHw_layerc3d_Initialize(XHw_layerc3d *InstancePtr, UINTPTR BaseAddress) {
	XHw_layerc3d_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHw_layerc3d_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHw_layerc3d_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XHw_layerc3d_Config *XHw_layerc3d_LookupConfig(u16 DeviceId) {
	XHw_layerc3d_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XHW_LAYERC3D_NUM_INSTANCES; Index++) {
		if (XHw_layerc3d_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XHw_layerc3d_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHw_layerc3d_Initialize(XHw_layerc3d *InstancePtr, u16 DeviceId) {
	XHw_layerc3d_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHw_layerc3d_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHw_layerc3d_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

